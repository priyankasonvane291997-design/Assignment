package com.example.demo.controller;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Movie;
import com.example.demo.model.Seat;
import com.example.demo.model.Show;
import com.example.demo.repo.MovieRepo;
import com.example.demo.repo.SeatRepo;
import com.example.demo.repo.ShowRepo;

@RestController
@RequestMapping("/api/admin")
public class AdminController {
	@Autowired
	private MovieRepo movieRepo;
	@Autowired
	private ShowRepo showRepo;
	@Autowired
	private SeatRepo seatRepo;
	@Autowired
	private AuthController auth;

	@PostMapping("/movie")
	public Movie addMovie(@RequestHeader(value = "X-Auth-Token", required = false) String t, @RequestBody Movie m) {
		if (auth.getByToken(t) == null)
			throw new RuntimeException("unauth");
		return movieRepo.save(m);
	}

	@PostMapping("/show")
	public Show addShow(@RequestHeader(value = "X-Auth-Token", required = false) String t, @RequestParam Long movieId) {
		if (auth.getByToken(t) == null)
			throw new RuntimeException("unauth");
		Movie mv = movieRepo.findById(movieId).orElseThrow(() -> new RuntimeException("no movie"));
		Show s = new Show();
		s.setMovie(mv);
		s.setStartTime(LocalDateTime.now().plusDays(1));
		s.setBasePrice(150);
		Show saved = showRepo.save(s);
		for (int i = 1; i <= 20; i++) {
			Seat seat = new Seat();
			seat.setShow(saved);
			seat.setSeatNumber("S" + i);
			seat.setBooked(false);
			seat.setPrice(150);
			seatRepo.save(seat);
		}
		return saved;
	}
}
