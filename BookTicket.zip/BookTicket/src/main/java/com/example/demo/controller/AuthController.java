package com.example.demo.controller;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.User;
import com.example.demo.repo.UserRepo;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
	@Autowired
	private UserRepo userRepo;
	private ConcurrentHashMap<String, User> tokens = new ConcurrentHashMap<>();

	@PostMapping("/register")
	public String register(@RequestBody User u) {
		userRepo.save(u);
		return "ok";
	}

	@PostMapping("/login")
	public String login(@RequestBody User r) {
		User u = userRepo.findByUsername(r.getUsername()).orElse(null);
		if (u == null || !u.getPassword().equals(r.getPassword()))
			return "invalid";
		String t = UUID.randomUUID().toString();
		tokens.put(t, u);
		System.out.println("User : "+r.toString() + " t : "+t);
		return t;
	}

	public User getByToken(String token) {
		System.out.println("tokens.get(token) : "+tokens.get(token));
		return tokens.get(token);
	}
}
