package com.example.demo.controller;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.example.demo.model.Booking;
import com.example.demo.model.Seat;
import com.example.demo.model.User;
import com.example.demo.repo.BookingRepo;
import com.example.demo.repo.SeatRepo;
import com.example.demo.repo.ShowRepo;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {
	@Autowired
	private AuthController auth;
	@Autowired
	private SeatRepo seatRepo;
	@Autowired
	private ShowRepo showRepo;
	@Autowired
	private BookingRepo bookingRepo;

	@PostMapping
	public Booking book(@RequestHeader(value = "X-Auth-Token", required = false) String t, @RequestParam Long seatId) {
		User u = auth.getByToken(t);
		if (u == null)
			throw new RuntimeException("unauth");
		Seat seat = seatRepo.findById(seatId).orElseThrow(() -> new RuntimeException("no seat"));
		if (seat.isBooked())
			throw new RuntimeException("already booked");
		seat.setBooked(true);
		seatRepo.save(seat);
		Booking b = new Booking();
		b.setUser(u);
		b.setSeat(seat);
		b.setShow(seat.getShow());
		b.setAmount(seat.getPrice());
		b.setCreatedAt(LocalDateTime.now());
		System.out.println(b.toString());
		return bookingRepo.save(b);
	}

	@GetMapping("/my")
	public Optional<Booking> getMyBookings(@RequestHeader(value = "X-Auth-Token", required = false) String token) {
		User u = auth.getByToken(token);
		if (u == null) {
			throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Unauthorized: Invalid or missing token");
		}

		// Only customers should access their own bookings
		if (!"CUSTOMER".equalsIgnoreCase(u.getRole())) {
			throw new ResponseStatusException(HttpStatus.FORBIDDEN,
					"Forbidden: Only customers can view their own bookings");
		}

		return bookingRepo.findById(u.getId());
	}

}
