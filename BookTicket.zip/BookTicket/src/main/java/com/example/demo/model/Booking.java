package com.example.demo.model;

import javax.persistence.*;

import com.example.demo.model.Show;

import java.time.LocalDateTime;

@Entity
public class Booking {
	@Id
	@GeneratedValue
	private Long id;
	@ManyToOne
	private User user;
	@ManyToOne
	private Show show;
	@ManyToOne
	private Seat seat;
	private double amount;
	private LocalDateTime createdAt;

	// getters/setters
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User u) {
		this.user = u;
	}

	public Show getShow() {
		return show;
	}

	public void setShow(Show s) {
		this.show = s;
	}

	public Seat getSeat() {
		return seat;
	}

	public void setSeat(Seat s) {
		this.seat = s;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double a) {
		this.amount = a;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime t) {
		this.createdAt = t;
	}
}
