package com.example.demo.model;


import javax.persistence.*;

@Entity
public class Movie {
	@Id
	@GeneratedValue
	private Long id;
	private String title;
	private String description;

	// getters/setters
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String t) {
		this.title = t;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String d) {
		this.description = d;
	}
}
