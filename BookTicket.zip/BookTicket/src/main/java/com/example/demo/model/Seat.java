package com.example.demo.model;
import javax.persistence.*;

import com.example.demo.model.Show;

@Entity
public class Seat {
	@Id
	@GeneratedValue
	private Long id;
	private String seatNumber;
	@ManyToOne
	private Show show;
	private boolean booked;
	private double price;

	// getters/setters
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(String s) {
		this.seatNumber = s;
	}

	public Show getShow() {
		return show;
	}

	public void setShow(Show s) {
		this.show = s;
	}

	public boolean isBooked() {
		return booked;
	}

	public void setBooked(boolean b) {
		this.booked = b;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double p) {
		this.price = p;
	}
}
