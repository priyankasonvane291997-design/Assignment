package com.example.demo.model;

import javax.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "shows")
public class Show {
	@Id
	@GeneratedValue
	private Long id;
	@ManyToOne
	private Movie movie;
	private LocalDateTime startTime;
	private double basePrice;

	// getters/setters
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie m) {
		this.movie = m;
	}

	public LocalDateTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalDateTime s) {
		this.startTime = s;
	}

	public double getBasePrice() {
		return basePrice;
	}

	public void setBasePrice(double p) {
		this.basePrice = p;
	}
}