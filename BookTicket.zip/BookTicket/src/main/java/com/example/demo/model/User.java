package com.example.demo.model;

import javax.persistence.*;

@Entity
public class User {
	@Id
	@GeneratedValue
	private Long id;
	@Column(unique = true)
	private String username;
	private String password;
	private String role; // ADMIN or CUSTOMER
	// getters/setters

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String u) {
		this.username = u;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String p) {
		this.password = p;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String r) {
		this.role = r;
	}
}
