package com.example.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.Seat;

public interface SeatRepo extends JpaRepository<Seat, Long> {
	List<Seat> findByShowIdAndBookedFalse(Long showId);
}
