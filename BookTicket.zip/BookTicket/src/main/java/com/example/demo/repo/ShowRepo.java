package com.example.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.Show;

public interface ShowRepo extends JpaRepository<Show, Long> {
}
